script_name("RADIO")
script_author("Pavel Garson")

require 'lib.moonloader'
require 'lib.sampfuncs'
local sf = require 'sampfuncs'
local inicfg = require 'inicfg'

if doesDirectoryExist('moonloader\\config') == false then
	createDirectory('moonloader\\config')
end

local cfg = inicfg.load(nil, 'radio.ini')
if cfg == nil then
	local inidata =
	{
	main =
		{
			rtag = '[RTAG]',
			ftag = '[FTAG]',
		},
	};
	inicfg.save(inidata, 'radio.ini')
end
cfg = inicfg.load(nil, 'radio.ini')

function main()
	if not isSampLoaded() and not isSampfuncsLoaded() then return end
	while not isSampAvailable() do wait(100) end
	sampRegisterChatCommand('rr', SendRadioR)
	sampRegisterChatCommand('ff', SendRadioF)
	while true do
		wait(0)
	end
end

function SendRadioR(text)
	if text == '' then
		sampAddChatMessage('[ERROR]{ffffff} /rr [�����]',0xff0000)
	else
		sampSendChat(string.format('/r %s %s', cfg.main.rtag, text))
	end
end

function SendRadioF(text)
	if text == '' then
		sampAddChatMessage('[ERROR]{ffffff} /ff [�����]',0xff0000)
	else
		sampSendChat(string.format('/f %s %s', cfg.main.ftag, text))
	end
end