The certificate generation scripts here are copied from LuaSec


